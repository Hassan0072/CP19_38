from tkinter import *

###############
# Basic Setup #
###############

#Create Window
window = Tk()
#Set Window Title
window.title("Server")
#Set Window Size
window.geometry("440x450")
#Set Window's Background Color
window.configure(background='light grey')

#######################################################
# Variables That Will Store Input in 'Entry' Elements #
#######################################################
#This Will Store IP Address
IP = StringVar()
#This Will Store Port
PORT = StringVar()

#########################
# Button Event Handlers #
#########################
#This Will Happen When Connect Is Pressed
def connect_button_pressed():
    #Write Your Code Here
    #This Code Will Execute When 'connect' Button Is Pressed
    pass

#This Will Happen When Disconnect Is Pressed
def disconnect_button_pressed():
    #Write Your Code Here
    #This Code Will Execute When 'disconnect' Button Is Pressed
    pass

def directory_button_pressed():
    #Write Your Code Here
    #This Code Will Show The Directory When 'view directory' Button Is Pressed
    pass
    
##############
# Actual GUI #
##############
#Creates Title Label
title_label = Label(window,text="Server Software", bg="dark blue", fg="white", font="comicsansms 12 bold", borderwidth=3, relief=GROOVE)
#First Element Of Grid
title_label.grid(column=0,row=0)

#Creates IP Address Label
ip_address_label = Label(window,text="IP Address",font="comicsansms 10  ", bg="light grey", fg="black")
#Second Element Of Grid
ip_address_label.grid(column=0,row=1)

#Create IP Address Entry
ip_address_input = Entry(window,textvariable=IP)
#Third Element Of Grid
ip_address_input.grid(column=1,row=1)

#Create Port Label
port_label = Label(window,text="Port", bg="light grey",font="comicsansms 10  ", fg="black")
#Fourth Element Of Grid
port_label.grid(column=0,row=2)

#Create Port Entry
port_input = Entry(window,textvariable=PORT)
#Fifth Element Of Grid
port_input.grid(column=1,row=2)

#Create Server Output Label
server_output_label = Label(window,text="Server Output", bg="light grey", fg="black",font="comicsansms 14 bold")
#Sixth Element Of Grid
server_output_label.grid(column=0,row=3)

#Create Server Output Text
server_output = Text(window,width=56, height=20,bg='grey',fg='white')
#Seventh Element Of Grid
server_output.grid(column=0,columnspan=5,row=4,rowspan=4)

#Create Connect Button With Event Handler 'connect_button_pressed'
connect_button = Button(window,text="Connect",bg='green',fg='white',font="comicsansms 10 bold ",command=connect_button_pressed)
#Eighth Element Of Grid
connect_button.grid(column=0,row=8)

#Create Disconnect Button With Event Handler 'disconnect_button_pressed'
disconnect_button = Button(window,text="Disconnect",bg='red',fg='white',font="comicsansms 10 bold ",command=disconnect_button_pressed)
#Nineth Element Of Grid
disconnect_button.grid(column=1,row=8)

#Create View directory button With Event Handler 'view_directory_button'
view_directory_button = Button(window,text="View Directory",bg='white',fg='black',font="comicsansms 10 bold ",command=directory_button_pressed)
#Nineth Element Of Grid
view_directory_button.grid(column=2,row=8)

#GUI Main Loop
window.mainloop()   